<template>
    <div class="container">
        <p v-for="(item, idx) in list" :data-total="total" :key="idx">
            {{item}}
        </p>    
    </div>
</template>

<script>
export default {
    data: function () {
        return {
            list: ['hello world', '-- vue'],
            total: 123
        }
    }
}
</script>

<style lang="scss" scoped>
%flex {
    display: flex;
}
.container {
    @extend %flex;
    background: #eff;
}
</style>