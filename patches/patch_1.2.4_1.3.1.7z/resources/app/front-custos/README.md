# front-custos

一个前端开发的试验工具，用于懒得或不会写 gulpfile 时，能快速对不同项目生成常用的 gulp 任务。

## 安装方法

切换到所在目录，执行`npm install`。

```bash
cd path/to/front-custos
npm install
```

运行测试项目检查是否安装完成。

```bash
node test
```

更多内容请参考：

[https://github.com/krimeshu/front-custos-gui](https://github.com/krimeshu/front-custos-gui)
