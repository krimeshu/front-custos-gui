var es6Tests = require('./lib/es6-tests.es6');
// import es6Tests from 'lib/es6-tests';

es6Tests.test();

// import { foo } from './lib/small-module';
// foo();

